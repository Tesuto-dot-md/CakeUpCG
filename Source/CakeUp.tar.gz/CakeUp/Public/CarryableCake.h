#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CarryableCake.generated.h"

class UStaticMeshComponent;
class ACakeUpCharacter;

UCLASS()
class CAKEUP_API ACarryableCake : public AActor
{
    GENERATED_BODY()

public:
    ACarryableCake();

    virtual void BeginPlay() override;

    // Вызов с клиента: "толкнуть" торт
    UFUNCTION(Server, Reliable)
    void Server_AddImpulse(const FVector& Impulse, bool bVelChange);
    void Server_AddImpulse_Implementation(const FVector& Impulse, bool bVelChange);

    // Вызов с клиента: "поднял/опустил" (или переключить состояние)
    UFUNCTION(Server, Reliable)
    void Server_SetCarried(bool bCarried);
    void Server_SetCarried_Implementation(bool bCarried);

    // Более high-level хелпер, если вызываешь не напрямую Server_SetCarried
    UFUNCTION(Server, Reliable)
    void TryToggleCarryFromServer(ACakeUpCharacter* ByCharacter);
    void TryToggleCarryFromServer_Implementation(ACakeUpCharacter* ByCharacter);

protected:
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
    TObjectPtr<UStaticMeshComponent> Mesh;

    // Флаг "несут ли торт" — реплицируемый
    UPROPERTY(ReplicatedUsing=OnRep_IsCarried)
    bool bIsCarried = false;

    // Частота апдейта по сети (Hz) — можно настраивать в BP
    UPROPERTY(EditDefaultsOnly, Category="Network")
    float NetHz = 30.f;

    UFUNCTION()
    void OnRep_IsCarried();

    // Разбудить физ. тело на всех
    UFUNCTION(NetMulticast, Reliable)
    void Multicast_Wake();
    void Multicast_Wake_Implementation();

    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
};
