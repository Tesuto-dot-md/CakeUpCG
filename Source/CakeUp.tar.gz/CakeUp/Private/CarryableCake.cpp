#include "CarryableCake.h"
#include "Components/StaticMeshComponent.h"
#include "Net/UnrealNetwork.h"     // <-- обязательно для DOREPLIFETIME

ACarryableCake::ACarryableCake()
{
    bReplicates = true;
    SetReplicateMovement(true);

    Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
    SetRootComponent(Mesh);

    Mesh->SetIsReplicated(true);
    Mesh->SetSimulatePhysics(false);
    Mesh->SetEnableGravity(true);

    // вместо прямой записи в поля — используем сеттеры (UE 5.6)
    SetNetUpdateFrequency(NetHz);
    SetMinNetUpdateFrequency(FMath::Min(NetHz, 10.f));
}

void ACarryableCake::BeginPlay()
{
    Super::BeginPlay();

    // Только сервер симулирует физику
    if (HasAuthority())
    {
        Mesh->SetSimulatePhysics(true);
    }
    else
    {
        Mesh->SetSimulatePhysics(false);
    }
}

void ACarryableCake::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);
    DOREPLIFETIME(ACarryableCake, bIsCarried);
}

void ACarryableCake::Server_AddImpulse_Implementation(const FVector& Impulse, bool bVelChange)
{
    if (Mesh && Mesh->IsSimulatingPhysics())
    {
        Mesh->AddImpulse(Impulse, NAME_None, bVelChange);
        ForceNetUpdate();
        Multicast_Wake();
    }
}

void ACarryableCake::Multicast_Wake_Implementation()
{
    if (Mesh)
    {
        Mesh->WakeRigidBody();
    }
}

void ACarryableCake::Server_SetCarried_Implementation(bool bCarried)
{
    if (bIsCarried == bCarried) return;
    bIsCarried = bCarried;

    if (bIsCarried)
    {
        // при переноске — физику выключаем, трансформ ведёт Attach/SetActorTransform (сервер)
        Mesh->SetSimulatePhysics(false);
    }
    else
    {
        // отпустили — снова физика только на сервере
        Mesh->SetSimulatePhysics(HasAuthority());
        Mesh->WakeRigidBody();
    }

    ForceNetUpdate();
    OnRep_IsCarried(); // применим немедленно и на сервере
}

void ACarryableCake::OnRep_IsCarried()
{
    if (!HasAuthority())
    {
        // Клиенты НИКОГДА не симулируют физику торта — только сервер
        Mesh->SetSimulatePhysics(false);
    }
}

void ACarryableCake::TryToggleCarryFromServer_Implementation(ACakeUpCharacter* /*ByCharacter*/)
{
    // Здесь можно добавить валидацию (дистанция, право брать, лимиты и т.д.)
    Server_SetCarried(!bIsCarried);
}
